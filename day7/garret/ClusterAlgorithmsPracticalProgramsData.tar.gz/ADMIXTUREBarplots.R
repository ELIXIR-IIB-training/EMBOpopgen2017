## MAKES ADMIXTURE PLOTS

##########################################
## INPUT:

out.file="BrahuiYorubaSimulationChrom22ADMIXTURE.pdf"
input.filePRE="BrahuiYorubaSimulationChrom22.admixture."
input.fileID="BrahuiYorubaSimulationChrom22.admixture.ind"

cluster.vec=c(2,3,4,5,6,7,8)
#col.clusters=c(2,3,4,5,6,7,8,"orange","white","purple",1,"brown","lightblue")
col.clusters=c(colors()[62],colors()[81],6,8,colors()[115],"maroon",colors()[280],2,3,4,5,7,"white",1,"brown")

##########################################
## PROGRAM:

max.find=function(x) return(sort(x,decreasing=TRUE,index.return=TRUE)$ix[1])

                        ## (I) READ IN INDIVIDUAL ID INFO:
pop.vec=read.table(input.fileID,as.is=TRUE)[,3]
unique.pops=unique(pop.vec)
count=0
midpoint.vec=abline.vec=NULL
for (i in 1:length(unique.pops))
{
	midpoint.vec=c(midpoint.vec,count+sum(pop.vec==unique.pops[i])/2)
	abline.vec=c(abline.vec,count+sum(pop.vec==unique.pops[i]))
	count=count+sum(pop.vec==unique.pops[i])
}

                        ## (II) PLOT ALL CLUSTERS:
pdf(out.file,width=14,height=7)
layout(matrix(1:length(cluster.vec),ncol=1),widths=1,heights=c(rep(3,length(cluster.vec)-1),7))
for (k in 1:length(cluster.vec))
{
	x=read.table(paste(input.filePRE,cluster.vec[k],".Q",sep=''))
	assign.prob.mat=matrix(as.matrix(x),ncol=dim(x)[2])
	col.clusters.toplot=col.clusters[1:cluster.vec[k]]
	max.cluster=apply(assign.prob.mat,1,max.find)
	#unique.max=unique(max.cluster)
	if (k > 1)
	{
		match.mat=matrix(NA,nrow=cluster.vec[(k-1)],ncol=cluster.vec[k])
		for (j in 1:cluster.vec[(k-1)])
		{
			for (h in 1:cluster.vec[k])
			    match.mat[j,h]=length((1:dim(x)[1])[max.cluster.prev==j & max.cluster==h])
	        }
		match.mat.new=match.mat
		cluster.label=1:cluster.vec[k]
		cluster.label.prev=1:cluster.vec[(k-1)]
		col.order=NULL
		for (j in 1:(cluster.vec[k]-1))
		{
			max.j.val=max(apply(match.mat.new,1,max))[1]
			max.j.row=max.find(apply(match.mat.new,1,max))
			max.j=(1:length(cluster.label))[match.mat.new[max.j.row,]==max.j.val][1]
			col.clusters.toplot[cluster.label[max.j]]=col.clusters.prev[cluster.label.prev[max.j.row]]
			match.mat.new=matrix(match.mat.new[-max.j.row,-max.j],ncol=length(cluster.label)-1)
			cluster.label=cluster.label[-max.j]
			cluster.label.prev=cluster.label.prev[-max.j.row]
		}
		col.clusters.toplot[cluster.label]=col.clusters[cluster.vec[k]]
	}
	col.clusters.prev=col.clusters.toplot
	#assign.prob.mat=assign.prob.mat[,c(unique.max,setdiff(unique.max,1:cluster.vec[k]))]
	if (k < length(cluster.vec)) par(mar=c(0,5.0,0,0))
	if (k == length(cluster.vec)) par(mar=c(7.5,5.0,0,0))
	barplot(t(assign.prob.mat),space=0,ylab='',col=col.clusters.toplot,xlab='',main='',axes=FALSE,cex.main=1,border=NA,cex.lab=1)
	abline(v=abline.vec,lwd=6)
	#axis(2,at=seq(0,1,0.2),labels=seq(0,1,0.2),las=2,line=-3)
	axis(2,at=0.5,labels=paste("K = ",cluster.vec[k],sep=''),las=2,line=-4,cex.axis=3.7,col.axis=col.clusters[cluster.vec[k]],tick=FALSE)
	if (k==length(cluster.vec)) axis(1,at=midpoint.vec,labels=substring(unique.pops,1,9),las=2,cex.axis=1.8,tick=FALSE,line=-0.8)
	max.cluster.prev=max.cluster
}
dev.off()
warnings()

q(save='no')
