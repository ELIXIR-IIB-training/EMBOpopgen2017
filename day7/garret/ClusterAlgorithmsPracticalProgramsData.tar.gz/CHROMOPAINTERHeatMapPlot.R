## PLOTS BARPLOTS SHOWING CP OUTPUT FOR VARIOUS LEVELS OF FINESTRUCTURE TREE

##################################
## INPUT:

plot.tree='no'

if (plot.tree!='yes') out.file="BrahuiYorubaSimulationAllVersusAllChrom22HEATMAP.pdf"
if (plot.tree=='yes') out.file="BrahuiYorubaSimulationAllVersusAllChrom22HEATMAPWithTree.pdf"

filename.chromopainter="BrahuiYorubaSimulationAllVersusAllChrom22.chunklengths.out"
filename.idfile="example/BrahuiYorubaSimulation.idfile.txt"
filename.finestructure="BrahuiYorubaSimulationAllVersusAllChrom22.finestructureTREE.out"
quan.vals=c(0.025,0.975)   ## quantiles for heatmap range

##################################
## PROGRAM:

options(scipen=999)
#install.packages("ape")
library(ape)

                   ## (I) GET INDIVIDUAL INFORMATION:
id.mat=read.table(filename.idfile,as.is=TRUE)

                   ## (II) GET HEATMAP MATRIX:
heatmap.read=read.table(filename.chromopainter,header=TRUE)
heatmap.mat=matrix(as.matrix(heatmap.read[,-1]),ncol=dim(heatmap.read)[2]-1)
#for (i in 1:dim(heatmap.mat)[1]) heatmap.mat[i,]=heatmap.mat[i,]/sum(heatmap.mat[i,])
recipient.names=as.character(heatmap.read[,1])
rownames(heatmap.mat)=recipient.names
colnames(heatmap.mat)=names(heatmap.read)[2:dim(heatmap.read)[2]]
pop.vec=id.mat[,2][match(recipient.names,id.mat[,1])]
unique.pops=unique(pop.vec)
#pop.colors=rainbow(n=length(unique.pops))
pop.colors=c(colors()[91],colors()[142],colors()[137],colors()[99],colors()[73],colors()[24],colors()[68],colors()[201],colors()[43],colors()[50],colors()[116],colors()[81],colors()[94],colors()[514],colors()[552],colors()[525],colors()[78])
col.vec=rep(NA,length(pop.vec))
for (i in 1:length(unique.pops)) col.vec[pop.vec==unique.pops[i]]=pop.colors[i]

                   ## (III) PLOT:
pdf(out.file)
if (plot.tree!='yes') layout(matrix(c(1,2,3,3),nrow=2,byrow=F), width=c(8, 1), height=c(6,1))
                                 ## (III)-(A) PLOT TREE:
if (plot.tree=='yes')
{
	layout(matrix(c(1,2,3,4,4,4),nrow=3,byrow=F), width=c(8, 1), height=c(2,6,1))
	FS.tree=read.tree(filename.finestructure,skip=20)
      	FS.tip=FS.tree$tip
	FS.edge=FS.tree$edge
	FS.edge.length=FS.tree$edge.length
	heatmap.mat=heatmap.mat[match(FS.tip,recipient.names),match(FS.tip,recipient.names)]
	pop.vec=pop.vec[match(FS.tip,recipient.names)]
	col.vec=col.vec[match(FS.tip,recipient.names)]
                                                ## first find max number of merges (i.e. total tree height):
	tree.level.vec=first.merge.vec=rep(0,length(FS.tip))
	FS.edge.new=FS.edge
	for (i in max(c(FS.edge)):(length(FS.tip)+1))
	{
		FS.edge.i=FS.edge.new[FS.edge.new[,1]==i,]
		new.joins=FS.edge.i[,2]
		if (max(FS.edge.length[FS.edge.new[,1]==i])>0.9 || sum(first.merge.vec)==length(FS.tip)) tree.level.vec[new.joins]=max(tree.level.vec[new.joins])+1
		first.merge.vec[new.joins]=1
		FS.edge.new[FS.edge.new[,2]==i,2]=min(new.joins)
 	}
	tree.height=max(tree.level.vec)
                                                ## then plot:
	midpoint.vec=1:length(FS.tip)
	tree.level.vec=first.merge.vec=rep(0,length(FS.tip))
	nind.level.vec=rep(1,length(FS.tip))
	FS.edge.new=FS.edge
	tree.level=0
	par(mgp=c(0,0,0),mar=c(0,0,0,0.5),fig=c(0.02,0.92,0.85,0.99))  ## equal pop widths
 	plot(0,0,type='n',ylim=c(0,tree.height),xlim=c(1,length(FS.tip)),main='',xlab='',ylab='',axes=FALSE)
	for (i in max(c(FS.edge)):(length(FS.tip)+1))
	{
		FS.edge.i=FS.edge.new[FS.edge.new[,1]==i,]
		new.joins=FS.edge.i[,2]
		print(c(i,new.joins,tree.level.vec[new.joins],midpoint.vec[new.joins],nind.level.vec[new.joins],round(FS.edge.length[FS.edge.new[,1]==i],1)))
		if (max(FS.edge.length[FS.edge.new[,1]==i])>0.9 || sum(first.merge.vec)==length(FS.tip))
		{
                                     ## vertical rise:
			lines(c(midpoint.vec[new.joins[1]]/nind.level.vec[new.joins[1]],midpoint.vec[new.joins[1]]/nind.level.vec[new.joins[1]]),c(tree.level.vec[new.joins[1]],max(tree.level.vec[new.joins])+1),col=1)
			lines(c(midpoint.vec[new.joins[2]]/nind.level.vec[new.joins[2]],midpoint.vec[new.joins[2]]/nind.level.vec[new.joins[2]]),c(tree.level.vec[new.joins[2]],max(tree.level.vec[new.joins])+1),col=1)
			tree.level.vec[new.joins]=max(tree.level.vec[new.joins])+1
		}
                                     ## horizontal join:
		lines(c(midpoint.vec[new.joins[1]]/nind.level.vec[new.joins[1]],midpoint.vec[new.joins[2]]/nind.level.vec[new.joins[2]]),c(tree.level.vec[new.joins[1]],tree.level.vec[new.joins[1]]),col=1)
		nind.level.vec[new.joins]=rep(sum(nind.level.vec[new.joins]),2)
		midpoint.vec[new.joins]=rep(sum(midpoint.vec[new.joins]),2)      ## make new midpoint
		first.merge.vec[new.joins]=1
		FS.edge.new[FS.edge.new[,2]==i,2]=min(new.joins)
 	}
}

                                 ## (III)-(B) PLOT HEATMAP:
colby=0.05
some.colors2<-c("white",rgb(1,seq(1,colby,-colby),colby),rgb(1,colby,seq(colby,1,colby)),rgb(seq(1,colby,-colby),colby,1.0),"black")
heatmap.mat[heatmap.mat<quantile(c(heatmap.mat),quan.vals[1])]=quantile(c(heatmap.mat),quan.vals[1])
heatmap.mat[heatmap.mat>quantile(c(heatmap.mat),quan.vals[2])]=quantile(c(heatmap.mat),quan.vals[2])
colscale=c(min(c(heatmap.mat)),max(c(heatmap.mat)))
colindex=t(matrix(seq(colscale[1],colscale[2],length.out=100),ncol=1,nrow=100))
if (plot.tree!='yes') par(mar=c(2,2,0.5,0.5),fig=c(0.05,0.89,0.15,1.0))
if (plot.tree=='yes') par(mgp=c(0,0,0),mar=c(0,0,0,0.5),fig=c(0.05,0.89,0.11,0.85),new=TRUE)
image(1:dim(heatmap.mat)[1],1:dim(heatmap.mat)[2],heatmap.mat,xaxt="n",yaxt="n",xlab="",ylab="",col=some.colors2,zlim=colscale)
for (i in 1:dim(heatmap.mat)[1]) axis(1,at=i,labels="I",col.axis=col.vec[i],tick=FALSE,las=1,cex.axis=0.8,line=-0.25)
for (i in 1:dim(heatmap.mat)[1]) axis(2,at=i+0.5,labels="-",col.axis=col.vec[i],tick=FALSE,las=2,cex.axis=0.8,line=0)

                                 ## (III)-(C) PLOT POPULATION LEGEND:
if (plot.tree!='yes') par(mar=c(0,0,0,0),fig=c(0,0.9,0.0,0.17),new=TRUE)
if (plot.tree=='yes') par(mar=c(0,0,0,0),fig=c(0,0.9,0.0,0.11),new=TRUE)
plot(0,0,type='n',xlim=c(0,10),ylim=c(0,10),main="",ylab='',xlab='',axes=FALSE)
if (plot.tree!='yes') legend(0,10,legend=unique.pops,fill=pop.colors,ncol=3,cex=1,bty='n')
if (plot.tree=='yes') legend(0,10,legend=unique.pops,fill=pop.colors,ncol=4,cex=1,bty='n')

                                 ## (III)-(D) PLOT HEATMAP LEGEND:
par(las=2,mgp=c(0,1,0),mar=c(0,0,0,0.5),fig=c(0.90,0.95,0.05,0.95),new=T)
image(0,1:100,colindex,xaxt="n",yaxt="n",xlab="",ylab="",col=some.colors2,zlim=colscale)
box(lty=1)
axis(4,at=seq(1,100,length.out=10),labels=round(min(colindex)+(max(colindex)-min(colindex))*seq(0,1,length.out=10),2),las=2,tick=FALSE,cex.axis=1.3,line=-0.5)

dev.off()

cbind(unique.pops,pop.colors)

q(save='no')
